from fastapi import APIRouter, HTTPException, Depends, Request, Header
from datetime import datetime
import uuid

from app.models.user import User
from app.models.wallet import WalletFundingLog, FundingStatus
from app.models.transaction import Transaction, TransactionType, TransactionStatus, PaymentGateway
from app.schemas.services import InitiateFundingRequest, TransactionResponse
from app.services.auth_service import get_current_user
from app.services import payment_service, email_service

router = APIRouter(prefix="/wallet", tags=["Wallet"])


def _gen_ref() -> str:
    return f"SVW-{uuid.uuid4().hex[:12].upper()}"


# ── Initiate Funding ──────────────────────────────────────────────────────────
@router.post("/fund/initiate")
async def initiate_funding(
    body: InitiateFundingRequest,
    request: Request,
    current_user: User = Depends(get_current_user)
):
    """
    Step 1: Create a funding session and return a payment URL.
    Frontend redirects user to this URL to complete payment.
    """
    reference = _gen_ref()
    amount_kobo = int(body.amount * 100)
    base_url = str(request.base_url).rstrip("/")
    callback_url = f"{base_url}/wallet/fund/verify/{body.gateway}/{reference}"

    # Create log entry
    log = WalletFundingLog(
        user_id=str(current_user.id),
        reference=reference,
        gateway=body.gateway,
        amount_kobo=amount_kobo,
    )
    await log.insert()

    if body.gateway == "paystack":
        result = await payment_service.paystack_initialize(
            email=current_user.email,
            amount_kobo=amount_kobo,
            reference=reference,
            callback_url=callback_url,
        )
        if not result["success"]:
            raise HTTPException(400, result.get("message", "Paystack initialization failed"))
        return {
            "gateway": "paystack",
            "payment_url": result["authorization_url"],
            "reference": reference,
        }

    else:  # flutterwave
        result = await payment_service.flw_initialize(
            email=current_user.email,
            phone=current_user.phone,
            name=current_user.full_name,
            amount_naira=body.amount,
            reference=reference,
            redirect_url=callback_url,
        )
        if not result["success"]:
            raise HTTPException(400, result.get("message", "Flutterwave initialization failed"))
        return {
            "gateway": "flutterwave",
            "payment_url": result["payment_link"],
            "reference": reference,
        }


# ── Verify Funding (redirect callback) ───────────────────────────────────────
@router.get("/fund/verify/{gateway}/{reference}")
async def verify_funding(gateway: str, reference: str):
    """
    Step 2: User returns here after completing payment.
    Verifies the payment and credits the wallet.
    """
    log = await WalletFundingLog.find_one(WalletFundingLog.reference == reference)
    if not log:
        raise HTTPException(404, "Funding session not found")
    if log.status == FundingStatus.SUCCESS:
        return {"status": "already_verified", "message": "Wallet already credited"}

    user = await User.get(log.user_id)
    if not user:
        raise HTTPException(404, "User not found")

    verified = False
    amount_kobo = 0

    if gateway == "paystack":
        result = await payment_service.paystack_verify(reference)
        if result["success"]:
            verified = True
            amount_kobo = result["amount_kobo"]
            log.gateway_reference = str(result.get("gateway_reference", ""))
            log.gateway_response = result
    else:
        # Flutterwave: transaction_id is passed as query param by FLW
        # In production, extract from request query params
        result = await payment_service.flw_verify(reference)
        if result["success"]:
            verified = True
            amount_kobo = result["amount_kobo"]
            log.gateway_reference = str(result.get("gateway_reference", ""))
            log.gateway_response = result

    if not verified:
        log.status = FundingStatus.FAILED
        await log.save()
        raise HTTPException(400, "Payment verification failed")

    # Credit wallet
    balance_before = user.balance_kobo
    user.balance_kobo += amount_kobo
    user.updated_at = datetime.utcnow()
    await user.save()

    # Record transaction
    tx = Transaction(
        reference=reference,
        user_id=str(user.id),
        type=TransactionType.WALLET_FUNDING,
        status=TransactionStatus.SUCCESS,
        amount_kobo=amount_kobo,
        balance_before_kobo=balance_before,
        balance_after_kobo=user.balance_kobo,
        description=f"Wallet Funding via {gateway.capitalize()}",
        gateway=PaymentGateway(gateway),
        completed_at=datetime.utcnow(),
    )
    await tx.insert()

    log.status = FundingStatus.SUCCESS
    log.verified_at = datetime.utcnow()
    await log.save()

    # Send wallet funded email
    email_service.send_wallet_funded(
        user_email   = user.email,
        user_name    = user.full_name,
        first_name   = user.first_name,
        amount       = amount_kobo / 100,
        gateway      = gateway,
        reference    = reference,
        new_balance  = user.balance_naira,
        date_str     = datetime.utcnow().strftime("%d %b %Y, %H:%M UTC"),
    )

    return {
        "status": "success",
        "message": f"₦{amount_kobo/100:,.2f} added to your wallet",
        "new_balance": user.balance_naira,
    }


# ── Paystack Webhook ──────────────────────────────────────────────────────────
@router.post("/webhook/paystack")
async def paystack_webhook(request: Request, x_paystack_signature: str = Header(None)):
    """Paystack sends this when a payment completes (server-to-server)."""
    payload = await request.body()

    if not payment_service.verify_paystack_webhook(payload, x_paystack_signature or ""):
        raise HTTPException(400, "Invalid webhook signature")

    import json
    data = json.loads(payload)
    event = data.get("event")

    if event == "charge.success":
        reference = data["data"]["reference"]
        amount_kobo = data["data"]["amount"]

        log = await WalletFundingLog.find_one(WalletFundingLog.reference == reference)
        if log and log.status != FundingStatus.SUCCESS:
            user = await User.get(log.user_id)
            if user:
                balance_before = user.balance_kobo
                user.balance_kobo += amount_kobo
                await user.save()

                await Transaction(
                    reference=f"{reference}-WH",
                    user_id=str(user.id),
                    type=TransactionType.WALLET_FUNDING,
                    status=TransactionStatus.SUCCESS,
                    amount_kobo=amount_kobo,
                    balance_before_kobo=balance_before,
                    balance_after_kobo=user.balance_kobo,
                    description="Wallet Funding via Paystack (webhook)",
                    gateway=PaymentGateway.PAYSTACK,
                    completed_at=datetime.utcnow(),
                ).insert()

                log.status = FundingStatus.SUCCESS
                log.verified_at = datetime.utcnow()
                log.gateway_response = data["data"]
                await log.save()

    return {"status": "ok"}


# ── Flutterwave Webhook ───────────────────────────────────────────────────────
@router.post("/webhook/flutterwave")
async def flutterwave_webhook(
    request: Request,
    verif_hash: str = Header(None, alias="verif-hash")
):
    """Flutterwave webhook for completed payments."""
    payload = await request.body()

    if not payment_service.verify_flw_webhook(payload, verif_hash or ""):
        raise HTTPException(400, "Invalid webhook signature")

    import json
    data = json.loads(payload)

    if data.get("event") == "charge.completed" and data["data"]["status"] == "successful":
        reference = data["data"]["tx_ref"]
        amount_kobo = int(data["data"]["amount"] * 100)

        log = await WalletFundingLog.find_one(WalletFundingLog.reference == reference)
        if log and log.status != FundingStatus.SUCCESS:
            user = await User.get(log.user_id)
            if user:
                balance_before = user.balance_kobo
                user.balance_kobo += amount_kobo
                await user.save()

                await Transaction(
                    reference=f"{reference}-WH",
                    user_id=str(user.id),
                    type=TransactionType.WALLET_FUNDING,
                    status=TransactionStatus.SUCCESS,
                    amount_kobo=amount_kobo,
                    balance_before_kobo=balance_before,
                    balance_after_kobo=user.balance_kobo,
                    description="Wallet Funding via Flutterwave (webhook)",
                    gateway=PaymentGateway.FLUTTERWAVE,
                    completed_at=datetime.utcnow(),
                ).insert()

                log.status = FundingStatus.SUCCESS
                log.verified_at = datetime.utcnow()
                log.gateway_response = data["data"]
                await log.save()

    return {"status": "ok"}


# ── Transaction History ────────────────────────────────────────────────────────
@router.get("/transactions")
async def get_my_transactions(
    page: int = 1,
    limit: int = 20,
    type: str = None,
    current_user: User = Depends(get_current_user)
):
    skip = (page - 1) * limit
    query = Transaction.find(Transaction.user_id == str(current_user.id))
    if type:
        query = query.find(Transaction.type == type)
    total = await query.count()
    txs = await query.sort(-Transaction.created_at).skip(skip).limit(limit).to_list()

    return {
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit,
        "transactions": [
            {
                "id": str(tx.id),
                "reference": tx.reference,
                "type": tx.type,
                "status": tx.status,
                "amount_naira": tx.amount_naira,
                "description": tx.description,
                "token": tx.token,
                "created_at": tx.created_at,
            }
            for tx in txs
        ],
    }

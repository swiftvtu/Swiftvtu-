from fastapi import APIRouter, HTTPException, Depends, Request
from datetime import datetime, timedelta
import secrets
import random

from app.models.user import User, UserStatus
from app.schemas.auth import (
    RegisterRequest, LoginRequest, TokenResponse,
    RefreshRequest, UserResponse, ChangePasswordRequest, ForgotPasswordRequest, ResetPasswordRequest
)
from app.services.auth_service import (
    hash_password, verify_password,
    create_access_token, create_refresh_token,
    decode_token, get_current_user
)
from app.services import email_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


def user_to_response(user: User) -> UserResponse:
    return UserResponse(
        id=str(user.id),
        first_name=user.first_name,
        last_name=user.last_name,
        email=user.email,
        phone=user.phone,
        role=user.role,
        status=user.status,
        balance_naira=user.balance_naira,
        is_email_verified=user.is_email_verified,
        created_at=user.created_at,
    )


def _make_otp() -> str:
    return str(random.randint(100000, 999999))


@router.post("/register", response_model=TokenResponse, status_code=201)
async def register(body: RegisterRequest, request: Request):
    if await User.find_one(User.email == body.email):
        raise HTTPException(400, "An account with this email already exists")
    if await User.find_one(User.phone == body.phone):
        raise HTTPException(400, "An account with this phone number already exists")

    verify_token = secrets.token_urlsafe(32)
    otp          = _make_otp()
    verify_url   = f"{request.base_url}api/v1/auth/verify-email?token={verify_token}"

    user = User(
        first_name=body.first_name.strip(),
        last_name=body.last_name.strip(),
        email=body.email.lower().strip(),
        phone=body.phone,
        hashed_password=hash_password(body.password),
        email_verification_token=verify_token,
    )
    await user.insert()

    # Send welcome + verification email in background
    email_service.send_welcome(
        user.email, user.full_name, user.first_name, verify_url
    )
    email_service.send_verification_otp(
        user.email, user.full_name, user.first_name, otp, verify_url
    )

    return TokenResponse(
        access_token=create_access_token(str(user.id), user.role),
        refresh_token=create_refresh_token(str(user.id)),
        user=user_to_response(user),
    )


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest):
    user = await User.find_one(User.email == body.email.lower().strip())
    if not user or not verify_password(body.password, user.hashed_password):
        raise HTTPException(401, "Invalid email or password")
    if user.status == UserStatus.BLOCKED:
        raise HTTPException(403, "Your account has been suspended. Contact support.")

    user.last_login = datetime.utcnow()
    await user.save()

    return TokenResponse(
        access_token=create_access_token(str(user.id), user.role),
        refresh_token=create_refresh_token(str(user.id)),
        user=user_to_response(user),
    )


@router.get("/verify-email")
async def verify_email(token: str):
    user = await User.find_one(User.email_verification_token == token)
    if not user:
        raise HTTPException(400, "Invalid or expired verification link")
    user.is_email_verified       = True
    user.email_verification_token = None
    user.updated_at = datetime.utcnow()
    await user.save()
    return {"message": "Email verified successfully! You can now log in."}


@router.post("/resend-verification")
async def resend_verification(request: Request, current_user: User = Depends(get_current_user)):
    if current_user.is_email_verified:
        raise HTTPException(400, "Email already verified")
    otp          = _make_otp()
    verify_token = secrets.token_urlsafe(32)
    verify_url   = f"{request.base_url}api/v1/auth/verify-email?token={verify_token}"
    current_user.email_verification_token = verify_token
    await current_user.save()
    email_service.send_verification_otp(
        current_user.email, current_user.full_name,
        current_user.first_name, otp, verify_url
    )
    return {"message": "Verification email resent"}


@router.post("/refresh", response_model=TokenResponse)
async def refresh_tokens(body: RefreshRequest):
    payload = decode_token(body.refresh_token)
    if payload.get("type") != "refresh":
        raise HTTPException(401, "Invalid refresh token")
    user = await User.get(payload["sub"])
    if not user:
        raise HTTPException(401, "User not found")
    if user.status == UserStatus.BLOCKED:
        raise HTTPException(403, "Account suspended")
    return TokenResponse(
        access_token=create_access_token(str(user.id), user.role),
        refresh_token=create_refresh_token(str(user.id)),
        user=user_to_response(user),
    )


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return user_to_response(current_user)


@router.patch("/me")
async def update_profile(body: dict, current_user: User = Depends(get_current_user)):
    for field in {"first_name", "last_name"}:
        if field in body and body[field]:
            setattr(current_user, field, body[field].strip())
    current_user.updated_at = datetime.utcnow()
    await current_user.save()
    return user_to_response(current_user)


@router.post("/change-password")
async def change_password(body: ChangePasswordRequest, current_user: User = Depends(get_current_user)):
    if not verify_password(body.current_password, current_user.hashed_password):
        raise HTTPException(400, "Current password is incorrect")
    current_user.hashed_password = hash_password(body.new_password)
    current_user.updated_at = datetime.utcnow()
    await current_user.save()
    # Notify via email
    email_service.send_otp(
        current_user.email, current_user.full_name,
        current_user.first_name, "N/A", "password change confirmation"
    )
    return {"message": "Password updated successfully"}


@router.post("/forgot-password")
async def forgot_password(body: ForgotPasswordRequest, request: Request):
    user = await User.find_one(User.email == body.email.lower())
    if user:
        token      = secrets.token_urlsafe(32)
        reset_url  = f"{request.base_url}reset-password?token={token}"
        expires_at = datetime.utcnow() + timedelta(minutes=30)
        user.password_reset_token   = token
        user.password_reset_expires = expires_at
        await user.save()
        email_service.send_password_reset(
            user.email, user.full_name, user.first_name, reset_url
        )
    return {"message": "If that email exists, a reset link has been sent"}


@router.post("/reset-password")
async def reset_password(body: ResetPasswordRequest):
    user = await User.find_one(User.password_reset_token == body.token)
    if not user:
        raise HTTPException(400, "Invalid or expired reset token")
    if user.password_reset_expires and datetime.utcnow() > user.password_reset_expires:
        raise HTTPException(400, "Reset link has expired. Request a new one.")
    user.hashed_password        = hash_password(body.new_password)
    user.password_reset_token   = None
    user.password_reset_expires = None
    user.updated_at             = datetime.utcnow()
    await user.save()
    return {"message": "Password reset successfully. You can now log in."}

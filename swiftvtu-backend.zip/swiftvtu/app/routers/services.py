from fastapi import APIRouter, HTTPException, Depends, Request
from datetime import datetime
import uuid

from app.models.user import User
from app.models.transaction import Transaction, TransactionType, TransactionStatus, PaymentGateway
from app.schemas.services import (
    AirtimeRequest, DataRequest, ElectricityRequest, VerifyMeterRequest,
    CableTVRequest, VerifySmartcardRequest, InternetRequest,
    ExamPinRequest, BettingRequest, TransactionResponse
)
from app.services.auth_service import get_current_user
from app.services import vtpass_service, email_service

router = APIRouter(prefix="/services", tags=["VTU Services"])


def _gen_ref() -> str:
    return f"SVT-{uuid.uuid4().hex[:12].upper()}"


def _vtpass_success(code: str) -> bool:
    """VTpass returns '000' for success."""
    return code in ("000", "099")


async def _deduct_and_create_tx(
    user: User,
    amount_naira: float,
    tx_type: TransactionType,
    description: str,
    extra: dict = None,
) -> tuple[Transaction, str]:
    """Deduct wallet balance and create a pending transaction."""
    amount_kobo = int(amount_naira * 100)
    if user.balance_kobo < amount_kobo:
        raise HTTPException(400, f"Insufficient wallet balance. Your balance is ₦{user.balance_naira:,.2f}")

    reference = _gen_ref()
    balance_before = user.balance_kobo

    # Deduct balance
    user.balance_kobo -= amount_kobo
    user.updated_at = datetime.utcnow()
    await user.save()

    tx = Transaction(
        reference=reference,
        user_id=str(user.id),
        type=tx_type,
        status=TransactionStatus.PENDING,
        amount_kobo=amount_kobo,
        balance_before_kobo=balance_before,
        balance_after_kobo=user.balance_kobo,
        description=description,
        gateway=PaymentGateway.VTPASS,
        **(extra or {}),
    )
    await tx.insert()
    return tx, reference


async def _finalize_tx(tx: Transaction, user: User, vtpass_resp: dict):
    """Update transaction, refund on failure, and send email receipt."""
    code = vtpass_resp.get("code", "error")
    tx.vtpass_response = vtpass_resp
    tx.updated_at = datetime.utcnow()

    if _vtpass_success(code):
        tx.status = TransactionStatus.SUCCESS
        tx.completed_at = datetime.utcnow()
        content = vtpass_resp.get("content", {})
        tx_data = content.get("transactions", {})
        tx.token = tx_data.get("token")
        if "pins" in tx_data:
            tx.pins = [p.get("pin") for p in tx_data.get("pins", [])]
        tx.external_reference = tx_data.get("transactionId")
        await tx.save()

        # ── Send receipt email ──────────────────────────────────────────
        email_service.send_transaction_receipt(
            user_email   = user.email,
            user_name    = user.full_name,
            first_name   = user.first_name,
            tx_type      = tx.type.value.replace("_", " ").title(),
            reference    = tx.reference,
            amount       = tx.amount_naira,
            description  = tx.description,
            status       = "success",
            balance_after= user.balance_naira,
            date_str     = tx.completed_at.strftime("%d %b %Y, %H:%M UTC"),
            token        = tx.token,
            pins         = tx.pins,
        )

        # Low balance alert — warn if below ₦500
        if user.balance_kobo < 50000:
            email_service.send_low_balance_alert(
                user.email, user.full_name, user.first_name, user.balance_naira
            )

    else:
        tx.status = TransactionStatus.FAILED
        user.balance_kobo += tx.amount_kobo
        user.updated_at = datetime.utcnow()
        await user.save()
        await tx.save()

        # ── Send failure email ──────────────────────────────────────────
        reason = vtpass_resp.get("response_description", "Provider error")
        email_service.send_transaction_failed(
            user_email = user.email,
            user_name  = user.full_name,
            first_name = user.first_name,
            tx_type    = tx.type.value.replace("_", " ").title(),
            reference  = tx.reference,
            amount     = tx.amount_naira,
            reason     = reason,
        )

    return tx


# ── Airtime ───────────────────────────────────────────────────────────────────
@router.post("/airtime", response_model=TransactionResponse)
async def buy_airtime(body: AirtimeRequest, current_user: User = Depends(get_current_user)):
    desc = f"{body.network.upper()} Airtime → {body.phone}"
    tx, ref = await _deduct_and_create_tx(
        current_user, body.amount, TransactionType.AIRTIME, desc,
        extra={"network": body.network, "phone": body.phone}
    )

    vtpass_resp = await vtpass_service.purchase_airtime(
        body.network, body.phone, body.amount, ref
    )
    tx = await _finalize_tx(tx, current_user, vtpass_resp)

    if tx.status == TransactionStatus.FAILED:
        raise HTTPException(400, vtpass_resp.get("response_description", "Airtime purchase failed"))

    return _tx_to_response(tx)


# ── Data ──────────────────────────────────────────────────────────────────────
@router.get("/data/plans/{service_id}")
async def get_data_plans(service_id: str, _: User = Depends(get_current_user)):
    """Fetch available data plans for a network."""
    result = await vtpass_service.get_service_variations(service_id)
    return result


@router.post("/data", response_model=TransactionResponse)
async def buy_data(body: DataRequest, current_user: User = Depends(get_current_user)):
    # Get variation details to know the price
    plans = await vtpass_service.get_service_variations(body.network)
    variations = plans.get("content", {}).get("varations", [])
    plan = next((v for v in variations if v.get("variation_code") == body.variation_code), None)
    if not plan:
        raise HTTPException(400, "Invalid data plan selected")

    amount = float(plan.get("variation_amount", 0))
    desc = f"{body.network.upper()} {plan.get('name', 'Data')} → {body.phone}"

    tx, ref = await _deduct_and_create_tx(
        current_user, amount, TransactionType.DATA, desc,
        extra={"network": body.network, "phone": body.phone, "variation_code": body.variation_code}
    )

    vtpass_resp = await vtpass_service.purchase_data(body.network, body.phone, body.variation_code, ref)
    tx = await _finalize_tx(tx, current_user, vtpass_resp)

    if tx.status == TransactionStatus.FAILED:
        raise HTTPException(400, vtpass_resp.get("response_description", "Data purchase failed"))

    return _tx_to_response(tx)


# ── Electricity ───────────────────────────────────────────────────────────────
@router.post("/electricity/verify-meter")
async def verify_meter(body: VerifyMeterRequest, _: User = Depends(get_current_user)):
    result = await vtpass_service.verify_meter(body.disco, body.meter_type, body.meter_number)
    if result.get("code") == "error":
        raise HTTPException(400, result.get("response_description", "Meter verification failed"))
    return result


@router.post("/electricity", response_model=TransactionResponse)
async def pay_electricity(body: ElectricityRequest, current_user: User = Depends(get_current_user)):
    desc = f"{body.disco.upper()} {body.meter_type.capitalize()} → Meter {body.meter_number}"
    tx, ref = await _deduct_and_create_tx(
        current_user, body.amount, TransactionType.ELECTRICITY, desc,
        extra={"service_id": body.disco, "meter_number": body.meter_number}
    )

    vtpass_resp = await vtpass_service.purchase_electricity(
        body.disco, body.meter_type, body.meter_number, body.amount, current_user.phone, ref
    )
    tx = await _finalize_tx(tx, current_user, vtpass_resp)

    if tx.status == TransactionStatus.FAILED:
        raise HTTPException(400, vtpass_resp.get("response_description", "Electricity payment failed"))

    return _tx_to_response(tx)


# ── Cable TV ──────────────────────────────────────────────────────────────────
@router.post("/cable-tv/verify")
async def verify_smartcard(body: VerifySmartcardRequest, _: User = Depends(get_current_user)):
    result = await vtpass_service.verify_smartcard(body.service_id, body.smartcard_number)
    if result.get("code") == "error":
        raise HTTPException(400, result.get("response_description", "Smartcard verification failed"))
    return result


@router.get("/cable-tv/plans/{service_id}")
async def get_cable_plans(service_id: str, _: User = Depends(get_current_user)):
    return await vtpass_service.get_service_variations(service_id)


@router.post("/cable-tv", response_model=TransactionResponse)
async def pay_cable_tv(body: CableTVRequest, current_user: User = Depends(get_current_user)):
    plans = await vtpass_service.get_service_variations(body.service_id)
    variations = plans.get("content", {}).get("varations", [])
    plan = next((v for v in variations if v.get("variation_code") == body.variation_code), None)
    if not plan:
        raise HTTPException(400, "Invalid subscription plan")

    amount = float(plan.get("variation_amount", 0))
    desc = f"{body.service_id.upper()} {plan.get('name', 'Subscription')} → {body.smartcard_number}"

    tx, ref = await _deduct_and_create_tx(
        current_user, amount, TransactionType.CABLE_TV, desc,
        extra={"service_id": body.service_id, "smartcard_number": body.smartcard_number}
    )

    vtpass_resp = await vtpass_service.purchase_cable_tv(
        body.service_id, body.smartcard_number, body.variation_code, current_user.phone, ref
    )
    tx = await _finalize_tx(tx, current_user, vtpass_resp)

    if tx.status == TransactionStatus.FAILED:
        raise HTTPException(400, vtpass_resp.get("response_description", "Cable TV payment failed"))

    return _tx_to_response(tx)


# ── Exam Pins ─────────────────────────────────────────────────────────────────
@router.post("/exam-pins", response_model=TransactionResponse)
async def buy_exam_pins(body: ExamPinRequest, current_user: User = Depends(get_current_user)):
    plans = await vtpass_service.get_service_variations(body.service_id)
    variations = plans.get("content", {}).get("varations", [])
    if not variations:
        raise HTTPException(400, "Could not fetch exam pin pricing")

    unit_price = float(variations[0].get("variation_amount", 0))
    amount = unit_price * body.quantity
    desc = f"{body.service_id.upper()} x{body.quantity} Pin(s)"

    tx, ref = await _deduct_and_create_tx(
        current_user, amount, TransactionType.EXAM_PINS, desc,
        extra={"service_id": body.service_id}
    )

    vtpass_resp = await vtpass_service.purchase_exam_pin(
        body.service_id, body.quantity, current_user.phone, ref
    )
    tx = await _finalize_tx(tx, current_user, vtpass_resp)

    if tx.status == TransactionStatus.FAILED:
        raise HTTPException(400, vtpass_resp.get("response_description", "Exam pin purchase failed"))

    return _tx_to_response(tx)


# ── Betting ───────────────────────────────────────────────────────────────────
@router.post("/betting", response_model=TransactionResponse)
async def fund_betting(body: BettingRequest, current_user: User = Depends(get_current_user)):
    desc = f"{body.service_id.capitalize()} Wallet → ID {body.customer_id}"
    tx, ref = await _deduct_and_create_tx(
        current_user, body.amount, TransactionType.BETTING, desc,
        extra={"service_id": body.service_id, "account_number": body.customer_id}
    )

    vtpass_resp = await vtpass_service.purchase_betting(
        body.service_id, body.customer_id, body.amount, current_user.phone, ref
    )
    tx = await _finalize_tx(tx, current_user, vtpass_resp)

    if tx.status == TransactionStatus.FAILED:
        raise HTTPException(400, vtpass_resp.get("response_description", "Betting top-up failed"))

    return _tx_to_response(tx)


# ── Helpers ───────────────────────────────────────────────────────────────────
def _tx_to_response(tx: Transaction) -> TransactionResponse:
    return TransactionResponse(
        id=str(tx.id),
        reference=tx.reference,
        type=tx.type,
        status=tx.status,
        amount_naira=tx.amount_naira,
        description=tx.description,
        token=tx.token,
        pins=tx.pins,
        created_at=tx.created_at,
    )

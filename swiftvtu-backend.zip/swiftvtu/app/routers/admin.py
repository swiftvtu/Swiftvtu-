from fastapi import APIRouter, HTTPException, Depends
from datetime import datetime, timedelta
from typing import Optional

from app.models.user import User, UserStatus, UserRole
from app.models.transaction import Transaction, TransactionType, TransactionStatus, PaymentGateway
from app.schemas.services import AdminFundWalletRequest
from app.services.auth_service import require_admin
from app.services import email_service

router = APIRouter(prefix="/admin", tags=["Admin"])


# ── Users ─────────────────────────────────────────────────────────────────────
@router.get("/users")
async def list_users(
    page: int = 1,
    limit: int = 20,
    search: str = None,
    status: str = None,
    _: User = Depends(require_admin)
):
    query = User.find()
    if status and status in ("active", "blocked", "pending"):
        query = query.find(User.status == UserStatus(status))

    users = await query.sort(-User.created_at).to_list()

    if search:
        s = search.lower()
        users = [
            u for u in users
            if s in u.email.lower()
            or s in u.phone
            or s in (u.first_name + " " + u.last_name).lower()
        ]

    total = len(users)
    start = (page - 1) * limit
    paginated = users[start: start + limit]

    return {
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit,
        "users": [
            {
                "id": str(u.id),
                "name": u.full_name,
                "email": u.email,
                "phone": u.phone,
                "role": u.role,
                "status": u.status,
                "balance_naira": u.balance_naira,
                "created_at": u.created_at,
                "last_login": u.last_login,
            }
            for u in paginated
        ],
    }


@router.get("/users/{user_id}")
async def get_user(user_id: str, _: User = Depends(require_admin)):
    user = await User.get(user_id)
    if not user:
        raise HTTPException(404, "User not found")

    txs = await Transaction.find(
        Transaction.user_id == user_id
    ).sort(-Transaction.created_at).limit(10).to_list()

    return {
        "id": str(user.id),
        "name": user.full_name,
        "email": user.email,
        "phone": user.phone,
        "role": user.role,
        "status": user.status,
        "balance_naira": user.balance_naira,
        "created_at": user.created_at,
        "last_login": user.last_login,
        "recent_transactions": [
            {
                "reference": tx.reference,
                "type": tx.type,
                "amount_naira": tx.amount_naira,
                "status": tx.status,
                "created_at": tx.created_at,
            }
            for tx in txs
        ],
    }


@router.patch("/users/{user_id}/status")
async def update_user_status(
    user_id: str,
    body: dict,
    admin: User = Depends(require_admin)
):
    user = await User.get(user_id)
    if not user:
        raise HTTPException(404, "User not found")
    if str(user.id) == str(admin.id):
        raise HTTPException(400, "Cannot modify your own account status")

    new_status = body.get("status")
    if new_status not in ("active", "blocked"):
        raise HTTPException(400, "Status must be active or blocked")

    user.status = UserStatus(new_status)
    user.updated_at = datetime.utcnow()
    await user.save()

    if new_status == "blocked":
        email_service.send_account_blocked(user.email, user.full_name, user.first_name)

    return {"message": f"User {user.full_name} is now {new_status}"}


@router.delete("/users/{user_id}")
async def delete_user(user_id: str, admin: User = Depends(require_admin)):
    user = await User.get(user_id)
    if not user:
        raise HTTPException(404, "User not found")
    if str(user.id) == str(admin.id):
        raise HTTPException(400, "Cannot delete your own account")
    await user.delete()
    return {"message": f"User {user.full_name} deleted"}


# ── Transactions ──────────────────────────────────────────────────────────────
@router.get("/transactions")
async def list_transactions(
    page: int = 1,
    limit: int = 30,
    type: Optional[str] = None,
    status: Optional[str] = None,
    user_id: Optional[str] = None,
    _: User = Depends(require_admin)
):
    query = Transaction.find()
    if type:
        query = query.find(Transaction.type == type)
    if status:
        query = query.find(Transaction.status == status)
    if user_id:
        query = query.find(Transaction.user_id == user_id)

    total = await query.count()
    txs = await query.sort(-Transaction.created_at).skip((page - 1) * limit).limit(limit).to_list()

    return {
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit,
        "transactions": [
            {
                "id": str(tx.id),
                "reference": tx.reference,
                "user_id": tx.user_id,
                "type": tx.type,
                "status": tx.status,
                "amount_naira": tx.amount_naira,
                "description": tx.description,
                "gateway": tx.gateway,
                "created_at": tx.created_at,
                "completed_at": tx.completed_at,
            }
            for tx in txs
        ],
    }


# ── Fund Wallets ──────────────────────────────────────────────────────────────
@router.post("/wallet/fund")
async def admin_fund_wallet(body: AdminFundWalletRequest, admin: User = Depends(require_admin)):
    user = await User.get(body.user_id)
    if not user:
        raise HTTPException(404, "User not found")

    amount_kobo = int(body.amount * 100)

    if body.action == "debit" and user.balance_kobo < amount_kobo:
        raise HTTPException(
            400,
            f"User balance (₦{user.balance_naira:,.2f}) is less than debit amount"
        )

    balance_before = user.balance_kobo
    if body.action == "credit":
        user.balance_kobo += amount_kobo
        tx_type = TransactionType.WALLET_CREDIT
        desc = f"Admin Credit — {body.note or 'Manual credit by admin'}"
    else:
        user.balance_kobo -= amount_kobo
        tx_type = TransactionType.WALLET_DEBIT
        desc = f"Admin Debit — {body.note or 'Manual debit by admin'}"

    user.updated_at = datetime.utcnow()
    await user.save()

    import uuid
    tx = Transaction(
        reference=f"ADM-{uuid.uuid4().hex[:10].upper()}",
        user_id=str(user.id),
        type=tx_type,
        status=TransactionStatus.SUCCESS,
        amount_kobo=amount_kobo,
        balance_before_kobo=balance_before,
        balance_after_kobo=user.balance_kobo,
        description=desc,
        gateway=PaymentGateway.ADMIN,
        admin_note=f"By admin {admin.email}: {body.note or ''}",
        completed_at=datetime.utcnow(),
    )
    await tx.insert()

    email_service.send_admin_wallet_action(
        user_email   = user.email,
        user_name    = user.full_name,
        first_name   = user.first_name,
        action       = body.action,
        amount       = body.amount,
        note         = body.note or "",
        new_balance  = user.balance_naira,
    )

    return {
        "message": f"₦{body.amount:,.2f} {'credited to' if body.action == 'credit' else 'debited from'} {user.full_name}",
        "new_balance": user.balance_naira,
        "reference": tx.reference,
    }


# ── Analytics ─────────────────────────────────────────────────────────────────
@router.get("/analytics/overview")
async def analytics_overview(_: User = Depends(require_admin)):
    all_tx = await Transaction.find().to_list()
    users = await User.find().to_list()

    success_tx = [t for t in all_tx if t.status == TransactionStatus.SUCCESS]
    total_revenue = sum(t.amount_kobo for t in success_tx if t.type != TransactionType.WALLET_FUNDING) / 100
    total_funded = sum(t.amount_kobo for t in success_tx if t.type == TransactionType.WALLET_FUNDING) / 100

    # By type
    by_type = {}
    for t in success_tx:
        key = t.type.value
        by_type[key] = by_type.get(key, 0) + t.amount_kobo
    by_type_naira = {k: v / 100 for k, v in by_type.items()}

    # Last 7 days revenue
    seven_days = []
    for i in range(6, -1, -1):
        day = datetime.utcnow() - timedelta(days=i)
        day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day.replace(hour=23, minute=59, second=59)
        day_tx = [
            t for t in success_tx
            if day_start <= t.created_at <= day_end
            and t.type != TransactionType.WALLET_FUNDING
        ]
        seven_days.append({
            "date": day_start.strftime("%a"),
            "revenue": sum(t.amount_kobo for t in day_tx) / 100,
            "count": len(day_tx),
        })

    return {
        "total_users": len(users),
        "active_users": sum(1 for u in users if u.status == UserStatus.ACTIVE),
        "blocked_users": sum(1 for u in users if u.status == UserStatus.BLOCKED),
        "total_transactions": len(all_tx),
        "successful_transactions": len(success_tx),
        "failed_transactions": sum(1 for t in all_tx if t.status == TransactionStatus.FAILED),
        "total_revenue_naira": total_revenue,
        "total_wallet_funded_naira": total_funded,
        "revenue_by_type": by_type_naira,
        "last_7_days": seven_days,
    }

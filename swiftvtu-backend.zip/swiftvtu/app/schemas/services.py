from pydantic import BaseModel, field_validator
from typing import Optional, Any
from datetime import datetime
import re


def validate_nigerian_phone(v: str) -> str:
    v = v.strip().replace(" ", "")
    if not re.match(r"^(0|\+234)[789][01]\d{8}$", v):
        raise ValueError("Enter a valid Nigerian phone number")
    if v.startswith("+234"):
        v = "0" + v[4:]
    return v


# ── Airtime ──────────────────────────────────
class AirtimeRequest(BaseModel):
    network: str                    # mtn, airtel, glo, etisalat
    phone: str
    amount: float                   # in Naira

    @field_validator("phone")
    @classmethod
    def val_phone(cls, v): return validate_nigerian_phone(v)

    @field_validator("network")
    @classmethod
    def val_network(cls, v: str) -> str:
        allowed = {"mtn", "airtel", "glo", "etisalat"}
        if v.lower() not in allowed:
            raise ValueError(f"Network must be one of {allowed}")
        return v.lower()

    @field_validator("amount")
    @classmethod
    def val_amount(cls, v: float) -> float:
        if v < 50:
            raise ValueError("Minimum airtime purchase is ₦50")
        if v > 50000:
            raise ValueError("Maximum airtime purchase is ₦50,000")
        return v


# ── Data ─────────────────────────────────────
class DataRequest(BaseModel):
    network: str                    # mtn-data, airtel-data, glo-sme-data, etisalat-data
    phone: str
    variation_code: str             # VTpass variation code e.g. "mtn-10gb-1000"

    @field_validator("phone")
    @classmethod
    def val_phone(cls, v): return validate_nigerian_phone(v)


# ── Electricity ───────────────────────────────
class ElectricityRequest(BaseModel):
    disco: str                      # VTpass service ID e.g. ikeja-electric
    meter_type: str                 # prepaid | postpaid
    meter_number: str
    amount: float                   # in Naira

    @field_validator("meter_type")
    @classmethod
    def val_meter_type(cls, v: str) -> str:
        if v.lower() not in {"prepaid", "postpaid"}:
            raise ValueError("meter_type must be prepaid or postpaid")
        return v.lower()

    @field_validator("amount")
    @classmethod
    def val_amount(cls, v: float) -> float:
        if v < 1000:
            raise ValueError("Minimum electricity payment is ₦1,000")
        return v


class VerifyMeterRequest(BaseModel):
    disco: str
    meter_type: str
    meter_number: str


# ── Cable TV ─────────────────────────────────
class CableTVRequest(BaseModel):
    service_id: str                 # dstv | gotv | startimes
    smartcard_number: str
    variation_code: str             # subscription plan code


class VerifySmartcardRequest(BaseModel):
    service_id: str
    smartcard_number: str


# ── Internet ─────────────────────────────────
class InternetRequest(BaseModel):
    service_id: str                 # spectranet | smile-direct
    account_number: str
    variation_code: str


# ── Exam Pins ─────────────────────────────────
class ExamPinRequest(BaseModel):
    service_id: str                 # waec | waec-registration | neco
    quantity: int = 1

    @field_validator("quantity")
    @classmethod
    def val_qty(cls, v: int) -> int:
        if not 1 <= v <= 10:
            raise ValueError("Quantity must be between 1 and 10")
        return v


# ── Betting ───────────────────────────────────
class BettingRequest(BaseModel):
    service_id: str                 # bet9ja | betking | 1xbet | sportybet
    customer_id: str
    amount: float

    @field_validator("amount")
    @classmethod
    def val_amount(cls, v: float) -> float:
        if v < 100:
            raise ValueError("Minimum betting top-up is ₦100")
        return v


# ── Wallet Funding ────────────────────────────
class InitiateFundingRequest(BaseModel):
    amount: float
    gateway: str                    # paystack | flutterwave

    @field_validator("gateway")
    @classmethod
    def val_gateway(cls, v: str) -> str:
        if v.lower() not in {"paystack", "flutterwave"}:
            raise ValueError("gateway must be paystack or flutterwave")
        return v.lower()

    @field_validator("amount")
    @classmethod
    def val_amount(cls, v: float) -> float:
        if v < 100:
            raise ValueError("Minimum funding amount is ₦100")
        if v > 1000000:
            raise ValueError("Maximum funding amount is ₦1,000,000")
        return v


# ── Admin ─────────────────────────────────────
class AdminFundWalletRequest(BaseModel):
    user_id: str
    action: str                     # credit | debit
    amount: float
    note: Optional[str] = None

    @field_validator("action")
    @classmethod
    def val_action(cls, v: str) -> str:
        if v.lower() not in {"credit", "debit"}:
            raise ValueError("action must be credit or debit")
        return v.lower()

    @field_validator("amount")
    @classmethod
    def val_amount(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("Amount must be greater than 0")
        return v


# ── Transaction response ──────────────────────
class TransactionResponse(BaseModel):
    id: str
    reference: str
    type: str
    status: str
    amount_naira: float
    description: str
    token: Optional[str] = None
    pins: Optional[list[str]] = None
    created_at: datetime

    class Config:
        from_attributes = True

from beanie import Document, Indexed
from pydantic import Field
from typing import Optional, Any
from datetime import datetime
from enum import Enum
from bson import ObjectId


class TransactionType(str, Enum):
    AIRTIME = "airtime"
    DATA = "data"
    ELECTRICITY = "electricity"
    CABLE_TV = "cable_tv"
    INTERNET = "internet"
    WATER = "water"
    EXAM_PINS = "exam_pins"
    BETTING = "betting"
    WALLET_FUNDING = "wallet_funding"
    WALLET_DEBIT = "wallet_debit"       # admin manual debit
    WALLET_CREDIT = "wallet_credit"     # admin manual credit


class TransactionStatus(str, Enum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
    REVERSED = "reversed"


class PaymentGateway(str, Enum):
    PAYSTACK = "paystack"
    FLUTTERWAVE = "flutterwave"
    VTPASS = "vtpass"
    ADMIN = "admin"


class Transaction(Document):
    # Core
    reference: Indexed(str, unique=True)          # Our internal ref
    external_reference: Optional[str] = None       # VTpass / gateway ref
    user_id: Indexed(str)                          # User ObjectId as string
    type: TransactionType
    status: TransactionStatus = TransactionStatus.PENDING

    # Amounts in kobo
    amount_kobo: int
    charge_kobo: int = 0                           # Platform fee
    balance_before_kobo: int = 0
    balance_after_kobo: int = 0

    # Service details
    service_id: Optional[str] = None               # VTpass service ID
    network: Optional[str] = None                  # MTN, Airtel, etc.
    phone: Optional[str] = None                    # Recipient phone
    meter_number: Optional[str] = None
    smartcard_number: Optional[str] = None
    account_number: Optional[str] = None
    plan_code: Optional[str] = None
    variation_code: Optional[str] = None

    # Gateway
    gateway: Optional[PaymentGateway] = None
    gateway_response: Optional[dict] = None        # Raw API response
    vtpass_response: Optional[dict] = None         # Raw VTpass response

    # Token / pins (for electricity/exam)
    token: Optional[str] = None
    pins: Optional[list[str]] = None

    # Meta
    description: str = ""
    admin_note: Optional[str] = None
    ip_address: Optional[str] = None

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None

    @property
    def amount_naira(self) -> float:
        return self.amount_kobo / 100

    class Settings:
        name = "transactions"

from beanie import Document
from pydantic import Field
from typing import Optional
from datetime import datetime
from enum import Enum


class FundingStatus(str, Enum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class WalletFundingLog(Document):
    """Tracks wallet top-up attempts via Paystack / Flutterwave."""
    user_id: str
    reference: str                          # Our reference sent to gateway
    gateway: str                            # paystack | flutterwave
    amount_kobo: int
    status: FundingStatus = FundingStatus.PENDING
    gateway_reference: Optional[str] = None
    gateway_response: Optional[dict] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    verified_at: Optional[datetime] = None

    class Settings:
        name = "wallet_funding_logs"

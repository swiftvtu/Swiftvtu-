"""
VTpass API integration.
Docs: https://vtpass.com/documentation
"""
import httpx
import uuid
import logging
from datetime import datetime
from app.config import settings

logger = logging.getLogger(__name__)

BASE_URL = settings.VTPASS_BASE_URL


def _headers() -> dict:
    return {
        "api-key": settings.VTPASS_API_KEY,
        "public-key": settings.VTPASS_PUBLIC_KEY,
        "secret-key": settings.VTPASS_SECRET_KEY,
        "Content-Type": "application/json",
    }


def _gen_request_id() -> str:
    """VTpass requires a unique request ID per transaction."""
    now = datetime.utcnow()
    return now.strftime("%Y%m%d%H%I%S") + str(uuid.uuid4().hex[:6]).upper()


# ── Service Variations ────────────────────────────────────────────────────────
async def get_service_variations(service_id: str) -> dict:
    """Fetch available plans/variations for a service (e.g. data plans)."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{BASE_URL}/service-variations",
            params={"serviceID": service_id},
            headers=_headers(),
        )
        resp.raise_for_status()
        return resp.json()


# ── Airtime ───────────────────────────────────────────────────────────────────
AIRTIME_SERVICE_MAP = {
    "mtn": "mtn",
    "airtel": "airtel",
    "glo": "glo",
    "etisalat": "etisalat",
}


async def purchase_airtime(network: str, phone: str, amount: float, reference: str) -> dict:
    service_id = AIRTIME_SERVICE_MAP.get(network.lower())
    if not service_id:
        return {"code": "error", "response_description": "Unknown network"}

    payload = {
        "request_id": _gen_request_id(),
        "serviceID": service_id,
        "amount": amount,
        "phone": phone,
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(f"{BASE_URL}/pay", json=payload, headers=_headers())
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"VTpass airtime response [{reference}]: {data.get('code')}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"VTpass airtime error [{reference}]: {e}")
            return {"code": "error", "response_description": str(e)}


# ── Data ──────────────────────────────────────────────────────────────────────
async def purchase_data(service_id: str, phone: str, variation_code: str, reference: str) -> dict:
    payload = {
        "request_id": _gen_request_id(),
        "serviceID": service_id,
        "billersCode": phone,
        "variation_code": variation_code,
        "amount": "",           # VTpass uses variation_code amount
        "phone": phone,
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(f"{BASE_URL}/pay", json=payload, headers=_headers())
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"VTpass data response [{reference}]: {data.get('code')}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"VTpass data error [{reference}]: {e}")
            return {"code": "error", "response_description": str(e)}


# ── Electricity ───────────────────────────────────────────────────────────────
async def verify_meter(disco: str, meter_type: str, meter_number: str) -> dict:
    """Verify a meter number before purchase."""
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(
                f"{BASE_URL}/merchant-verify",
                json={
                    "billersCode": meter_number,
                    "serviceID": disco,
                    "type": meter_type,
                },
                headers=_headers(),
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            logger.error(f"VTpass meter verify error: {e}")
            return {"code": "error", "response_description": str(e)}


async def purchase_electricity(
    disco: str, meter_type: str, meter_number: str, amount: float, phone: str, reference: str
) -> dict:
    payload = {
        "request_id": _gen_request_id(),
        "serviceID": disco,
        "billersCode": meter_number,
        "variation_code": meter_type,   # prepaid | postpaid
        "amount": amount,
        "phone": phone,
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(f"{BASE_URL}/pay", json=payload, headers=_headers())
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"VTpass electricity response [{reference}]: {data.get('code')}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"VTpass electricity error [{reference}]: {e}")
            return {"code": "error", "response_description": str(e)}


# ── Cable TV ──────────────────────────────────────────────────────────────────
async def verify_smartcard(service_id: str, smartcard_number: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(
                f"{BASE_URL}/merchant-verify",
                json={"billersCode": smartcard_number, "serviceID": service_id},
                headers=_headers(),
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            return {"code": "error", "response_description": str(e)}


async def purchase_cable_tv(
    service_id: str, smartcard_number: str, variation_code: str, phone: str, reference: str
) -> dict:
    payload = {
        "request_id": _gen_request_id(),
        "serviceID": service_id,
        "billersCode": smartcard_number,
        "variation_code": variation_code,
        "amount": "",
        "phone": phone,
        "subscription_type": "change",
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(f"{BASE_URL}/pay", json=payload, headers=_headers())
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"VTpass cable TV response [{reference}]: {data.get('code')}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"VTpass cable TV error [{reference}]: {e}")
            return {"code": "error", "response_description": str(e)}


# ── Exam Pins ─────────────────────────────────────────────────────────────────
async def purchase_exam_pin(service_id: str, quantity: int, phone: str, reference: str) -> dict:
    payload = {
        "request_id": _gen_request_id(),
        "serviceID": service_id,
        "quantity": quantity,
        "phone": phone,
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(f"{BASE_URL}/pay", json=payload, headers=_headers())
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"VTpass exam pins response [{reference}]: {data.get('code')}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"VTpass exam pins error [{reference}]: {e}")
            return {"code": "error", "response_description": str(e)}


# ── Betting ───────────────────────────────────────────────────────────────────
async def purchase_betting(service_id: str, customer_id: str, amount: float, phone: str, reference: str) -> dict:
    payload = {
        "request_id": _gen_request_id(),
        "serviceID": service_id,
        "billersCode": customer_id,
        "variation_code": "default",
        "amount": amount,
        "phone": phone,
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(f"{BASE_URL}/pay", json=payload, headers=_headers())
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"VTpass betting response [{reference}]: {data.get('code')}")
            return data
        except httpx.HTTPError as e:
            logger.error(f"VTpass betting error [{reference}]: {e}")
            return {"code": "error", "response_description": str(e)}


# ── Requery ───────────────────────────────────────────────────────────────────
async def requery_transaction(request_id: str) -> dict:
    """Check status of a pending VTpass transaction."""
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(
                f"{BASE_URL}/requery",
                json={"request_id": request_id},
                headers=_headers(),
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            return {"code": "error", "response_description": str(e)}

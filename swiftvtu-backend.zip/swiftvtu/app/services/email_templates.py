"""
SwiftVTU Email Templates
All emails use a consistent dark-on-light branded design.
"""

# ── Base wrapper ──────────────────────────────────────────────────────────────
def _wrap(title: str, body: str, preheader: str = "") -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title>{title}</title>
<!--[if mso]><noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript><![endif]-->
<style>
  *{{margin:0;padding:0;box-sizing:border-box}}
  body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#F1F5F9;color:#1E293B;-webkit-font-smoothing:antialiased}}
  .wrapper{{max-width:600px;margin:0 auto;padding:24px 16px}}
  .header{{background:#0B0F1A;border-radius:16px 16px 0 0;padding:28px 32px;text-align:center}}
  .logo{{font-size:26px;font-weight:800;color:#ffffff;letter-spacing:-0.5px}}
  .logo span{{color:#3B82F6}}
  .body{{background:#ffffff;padding:36px 32px;border-left:1px solid #E2E8F0;border-right:1px solid #E2E8F0}}
  .footer{{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:0 0 16px 16px;padding:24px 32px;text-align:center;font-size:12px;color:#94A3B8;line-height:1.6}}
  .footer a{{color:#3B82F6;text-decoration:none}}
  h1{{font-size:22px;font-weight:800;color:#0F172A;margin-bottom:8px;letter-spacing:-0.3px}}
  p{{font-size:15px;line-height:1.65;color:#475569;margin-bottom:16px}}
  .btn{{display:inline-block;background:#2563EB;color:#ffffff!important;text-decoration:none;padding:14px 32px;border-radius:10px;font-weight:700;font-size:15px;letter-spacing:-0.2px;margin:8px 0}}
  .btn-green{{background:#10B981}}
  .btn-red{{background:#EF4444}}
  .divider{{height:1px;background:#E2E8F0;margin:24px 0}}
  .info-box{{background:#F1F5F9;border-radius:10px;padding:20px 24px;margin:20px 0}}
  .info-row{{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px}}
  .info-row:last-child{{border-bottom:none}}
  .info-label{{color:#64748B;font-weight:500}}
  .info-value{{color:#0F172A;font-weight:700;text-align:right}}
  .token-box{{background:#0F2444;border:2px solid #2563EB;border-radius:12px;padding:20px;text-align:center;margin:20px 0}}
  .token-label{{font-size:12px;color:#93B4DC;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px}}
  .token-value{{font-size:24px;font-weight:800;color:#ffffff;letter-spacing:4px;font-family:monospace}}
  .otp-box{{background:#0F172A;border-radius:12px;padding:24px;text-align:center;margin:20px 0}}
  .otp-value{{font-size:40px;font-weight:800;color:#3B82F6;letter-spacing:12px;font-family:monospace}}
  .otp-expires{{font-size:13px;color:#64748B;margin-top:8px}}
  .amount-hero{{text-align:center;padding:24px 0}}
  .amount-label{{font-size:13px;color:#64748B;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}}
  .amount-value{{font-size:36px;font-weight:800;color:#10B981;letter-spacing:-1px}}
  .status-badge{{display:inline-block;padding:4px 14px;border-radius:20px;font-size:12px;font-weight:700}}
  .badge-success{{background:#D1FAE5;color:#059669}}
  .badge-failed{{background:#FEE2E2;color:#DC2626}}
  .badge-pending{{background:#FEF3C7;color:#D97706}}
  .alert-box{{border-left:4px solid #EF4444;background:#FEF2F2;border-radius:0 8px 8px 0;padding:14px 18px;margin:16px 0}}
  .alert-box p{{color:#991B1B;margin:0;font-size:14px}}
  .tip-box{{border-left:4px solid #3B82F6;background:#EFF6FF;border-radius:0 8px 8px 0;padding:14px 18px;margin:16px 0}}
  .tip-box p{{color:#1E40AF;margin:0;font-size:14px}}
  @media(max-width:600px){{
    .body{{padding:24px 20px}}
    .header{{padding:22px 20px}}
    .amount-value{{font-size:28px}}
    .otp-value{{font-size:32px;letter-spacing:8px}}
  }}
</style>
</head>
<body>
{"" if not preheader else f'<div style="display:none;max-height:0;overflow:hidden;mso-hide:all">{preheader}&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;</div>'}
<div class="wrapper">
  <div class="header">
    <div class="logo">Swift<span>VTU</span></div>
  </div>
  <div class="body">
    {body}
  </div>
  <div class="footer">
    <p>© 2025 SwiftVTU. All rights reserved.</p>
    <p>
      <a href="{{frontend_url}}">Visit App</a> &nbsp;·&nbsp;
      <a href="mailto:{{support_email}}">Contact Support</a> &nbsp;·&nbsp;
      <a href="{{frontend_url}}/unsubscribe">Unsubscribe</a>
    </p>
    <p style="margin-top:10px;color:#CBD5E1">
      This email was sent to {{email}}.<br/>
      SwiftVTU — Recharge. Pay. Relax.
    </p>
  </div>
</div>
</body>
</html>"""


# ── 1. Welcome / Registration ─────────────────────────────────────────────────
def welcome_email(first_name: str, verification_url: str) -> tuple[str, str]:
    subject = f"Welcome to SwiftVTU, {first_name}! 🎉"
    body = f"""
    <h1>Welcome, {first_name}! 👋</h1>
    <p>Your SwiftVTU account is ready. You can now buy airtime, data bundles, pay electricity bills, cable TV subscriptions and more — all in one place.</p>

    <div class="tip-box">
      <p>✅ Verify your email address to unlock all features and secure your account.</p>
    </div>

    <div style="text-align:center;margin:28px 0">
      <a href="{verification_url}" class="btn">Verify Email Address</a>
    </div>

    <p style="font-size:13px;color:#94A3B8">This link expires in 24 hours. If you didn't create an account, you can safely ignore this email.</p>

    <div class="divider"></div>

    <p style="font-size:14px;font-weight:700;color:#0F172A;margin-bottom:12px">What you can do with SwiftVTU:</p>
    <table width="100%" cellpadding="0" cellspacing="0">
      {"".join([f'<tr><td style="padding:8px 0;font-size:14px;color:#475569">{"".join(["<td style=\\"font-size:18px;width:32px;padding:8px 0\\">"+icon+"</td><td style=\\"font-size:14px;color:#475569;padding:8px 0\\">"+text+"</td>" for icon, text in [(icon, text)]])}</td></tr>' for icon, text in [("📱","Buy Airtime — all networks"), ("📡","Data Bundles — best rates"), ("💡","Electricity — token delivered instantly"), ("📺","Cable TV — DSTV, GOtv, Startimes"), ("🎓","Exam Pins — WAEC, NECO, NABTEB")]])}
    </table>
    """

    # Simpler approach for the feature list
    features = [
        ("📱", "Buy Airtime — all networks, instant delivery"),
        ("📡", "Data Bundles — best rates guaranteed"),
        ("💡", "Electricity — token delivered to your email"),
        ("📺", "Cable TV — DSTV, GOtv, Startimes"),
        ("🎓", "Exam Pins — WAEC, NECO, NABTEB"),
    ]
    feature_html = "".join(
        f'<p style="margin:6px 0;font-size:14px"><span style="margin-right:8px">{icon}</span>{text}</p>'
        for icon, text in features
    )

    body = f"""
    <h1>Welcome, {first_name}! 👋</h1>
    <p>Your SwiftVTU account is ready. Buy airtime, data, pay bills and more — all in one place.</p>

    <div class="tip-box">
      <p>✅ Verify your email to unlock all features and secure your account.</p>
    </div>

    <div style="text-align:center;margin:28px 0">
      <a href="{verification_url}" class="btn">Verify Email Address</a>
    </div>

    <p style="font-size:13px;color:#94A3B8;margin-bottom:20px">This link expires in 24 hours. If you didn't sign up, ignore this email.</p>

    <div class="divider"></div>
    <p style="font-size:14px;font-weight:700;color:#0F172A;margin-bottom:10px">What you can do:</p>
    {feature_html}
    """
    return subject, _wrap(subject, body, f"Welcome to SwiftVTU, {first_name}! Verify your email to get started.")


# ── 2. Email Verification ─────────────────────────────────────────────────────
def verify_email(first_name: str, verification_url: str, otp: str) -> tuple[str, str]:
    subject = "Verify your SwiftVTU email address"
    body = f"""
    <h1>Verify your email</h1>
    <p>Hi {first_name}, enter this code in the app to verify your email address:</p>

    <div class="otp-box">
      <div class="otp-value">{otp}</div>
      <div class="otp-expires">Expires in 10 minutes</div>
    </div>

    <p>Or click the button below:</p>
    <div style="text-align:center;margin:20px 0">
      <a href="{verification_url}" class="btn">Verify Email</a>
    </div>

    <div class="alert-box">
      <p>⚠️ Never share this code with anyone. SwiftVTU staff will never ask for it.</p>
    </div>
    """
    return subject, _wrap(subject, body, f"Your SwiftVTU verification code is {otp}")


# ── 3. OTP / Two-Factor Auth ──────────────────────────────────────────────────
def otp_email(first_name: str, otp: str, action: str = "login") -> tuple[str, str]:
    subject = f"Your SwiftVTU OTP — {otp}"
    body = f"""
    <h1>One-Time Password</h1>
    <p>Hi {first_name}, here's your OTP for <strong>{action}</strong>:</p>

    <div class="otp-box">
      <div class="otp-value">{otp}</div>
      <div class="otp-expires">Expires in 10 minutes · Do not share</div>
    </div>

    <div class="alert-box">
      <p>⚠️ If you didn't request this, secure your account immediately by changing your password.</p>
    </div>

    <p style="font-size:13px;color:#94A3B8">Request time: {"{requested_at}"}</p>
    """
    return subject, _wrap(subject, body, f"Your SwiftVTU OTP is {otp} — expires in 10 minutes")


# ── 4. Password Reset ─────────────────────────────────────────────────────────
def password_reset_email(first_name: str, reset_url: str, expires_minutes: int = 30) -> tuple[str, str]:
    subject = "Reset your SwiftVTU password"
    body = f"""
    <h1>Password Reset Request</h1>
    <p>Hi {first_name}, we received a request to reset your SwiftVTU password.</p>

    <div style="text-align:center;margin:28px 0">
      <a href="{reset_url}" class="btn btn-red">Reset My Password</a>
    </div>

    <div class="info-box">
      <div class="info-row">
        <span class="info-label">Link expires in</span>
        <span class="info-value">{expires_minutes} minutes</span>
      </div>
      <div class="info-row">
        <span class="info-label">Can only be used</span>
        <span class="info-value">Once</span>
      </div>
    </div>

    <div class="alert-box">
      <p>⚠️ If you didn't request a password reset, ignore this email. Your password remains unchanged.</p>
    </div>

    <p style="font-size:13px;color:#94A3B8">If the button doesn't work, copy and paste this link:<br/>
    <span style="color:#3B82F6;word-break:break-all">{reset_url}</span></p>
    """
    return subject, _wrap(subject, body, "Reset your SwiftVTU password — link expires soon")


# ── 5. Transaction Receipt ────────────────────────────────────────────────────
def transaction_receipt(
    first_name: str,
    tx_type: str,
    reference: str,
    amount: float,
    description: str,
    status: str,
    balance_after: float,
    date_str: str,
    token: str = None,
    pins: list = None,
    extra_rows: dict = None,
) -> tuple[str, str]:
    subject = f"✅ {tx_type} Successful — ₦{amount:,.2f} | SwiftVTU"
    status_badge = {
        "success": '<span class="status-badge badge-success">✓ Successful</span>',
        "failed":  '<span class="status-badge badge-failed">✗ Failed</span>',
        "pending": '<span class="status-badge badge-pending">⏳ Pending</span>',
    }.get(status, status)

    # Build extra detail rows
    extra_html = ""
    if extra_rows:
        for label, value in extra_rows.items():
            extra_html += f"""
            <div class="info-row">
              <span class="info-label">{label}</span>
              <span class="info-value">{value}</span>
            </div>"""

    # Token / pins block
    token_html = ""
    if token:
        token_html = f"""
        <div class="token-box">
          <div class="token-label">⚡ Electricity Token</div>
          <div class="token-value">{token}</div>
          <p style="font-size:12px;color:#93B4DC;margin-top:8px">Enter this token on your meter to credit your units</p>
        </div>"""
    if pins:
        token_html += "".join(f"""
        <div class="token-box" style="margin-top:12px">
          <div class="token-label">🎓 Exam PIN {i+1}</div>
          <div class="token-value" style="font-size:18px;letter-spacing:3px">{pin}</div>
        </div>""" for i, pin in enumerate(pins))

    body = f"""
    <h1>Transaction Receipt</h1>
    <p>Hi {first_name}, your transaction was processed successfully.</p>

    <div class="amount-hero">
      <div class="amount-label">Amount Paid</div>
      <div class="amount-value">₦{amount:,.2f}</div>
    </div>

    {token_html}

    <div class="info-box">
      <div class="info-row">
        <span class="info-label">Service</span>
        <span class="info-value">{tx_type}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Description</span>
        <span class="info-value">{description}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Reference</span>
        <span class="info-value" style="font-family:monospace;font-size:12px">{reference}</span>
      </div>
      {extra_html}
      <div class="info-row">
        <span class="info-label">Status</span>
        <span class="info-value">{status_badge}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Date & Time</span>
        <span class="info-value">{date_str}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Wallet Balance After</span>
        <span class="info-value" style="color:#10B981">₦{balance_after:,.2f}</span>
      </div>
    </div>

    <div class="tip-box">
      <p>💡 Keep this email as proof of payment. Reference: <strong>{reference}</strong></p>
    </div>

    <div style="text-align:center;margin-top:24px">
      <a href="{{frontend_url}}" class="btn btn-green">View Transaction History</a>
    </div>
    """
    return subject, _wrap(subject, body, f"{tx_type} of ₦{amount:,.2f} processed successfully")


# ── 6. Wallet Funded ──────────────────────────────────────────────────────────
def wallet_funded_email(
    first_name: str,
    amount: float,
    gateway: str,
    reference: str,
    new_balance: float,
    date_str: str,
) -> tuple[str, str]:
    subject = f"💰 Wallet Funded — ₦{amount:,.2f} added | SwiftVTU"
    body = f"""
    <h1>Wallet Funded Successfully</h1>
    <p>Hi {first_name}, ₦{amount:,.2f} has been added to your SwiftVTU wallet.</p>

    <div class="amount-hero">
      <div class="amount-label">Amount Added</div>
      <div class="amount-value">₦{amount:,.2f}</div>
    </div>

    <div class="info-box">
      <div class="info-row">
        <span class="info-label">Payment Method</span>
        <span class="info-value">{gateway.title()}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Reference</span>
        <span class="info-value" style="font-family:monospace;font-size:12px">{reference}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Date</span>
        <span class="info-value">{date_str}</span>
      </div>
      <div class="info-row">
        <span class="info-label">New Wallet Balance</span>
        <span class="info-value" style="color:#10B981;font-size:16px">₦{new_balance:,.2f}</span>
      </div>
    </div>

    <div style="text-align:center;margin-top:24px">
      <a href="{{frontend_url}}" class="btn btn-green">Start Transacting</a>
    </div>
    """
    return subject, _wrap(subject, body, f"₦{amount:,.2f} added to your SwiftVTU wallet")


# ── 7. Failed Transaction Alert ───────────────────────────────────────────────
def transaction_failed_email(
    first_name: str,
    tx_type: str,
    reference: str,
    amount: float,
    reason: str,
) -> tuple[str, str]:
    subject = f"⚠️ Transaction Failed — ₦{amount:,.2f} | SwiftVTU"
    body = f"""
    <h1>Transaction Failed</h1>
    <p>Hi {first_name}, your recent transaction could not be completed. <strong>Your wallet has been refunded.</strong></p>

    <div class="alert-box">
      <p>⚠️ Reason: {reason or "Provider error — please try again"}</p>
    </div>

    <div class="info-box">
      <div class="info-row">
        <span class="info-label">Service</span>
        <span class="info-value">{tx_type}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Amount</span>
        <span class="info-value">₦{amount:,.2f}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Reference</span>
        <span class="info-value" style="font-family:monospace;font-size:12px">{reference}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Refund Status</span>
        <span class="info-value" style="color:#10B981">✓ Refunded to wallet</span>
      </div>
    </div>

    <div style="text-align:center;margin:24px 0">
      <a href="{{frontend_url}}" class="btn">Try Again</a>
    </div>

    <p style="font-size:13px;color:#94A3B8">If you continue to experience issues, contact us at
    <a href="mailto:{{support_email}}" style="color:#3B82F6">{{support_email}}</a></p>
    """
    return subject, _wrap(subject, body, f"Your {tx_type} transaction failed — your wallet has been refunded")


# ── 8. Low Balance Alert ──────────────────────────────────────────────────────
def low_balance_email(first_name: str, balance: float) -> tuple[str, str]:
    subject = "⚠️ Low Wallet Balance | SwiftVTU"
    body = f"""
    <h1>Low Balance Alert</h1>
    <p>Hi {first_name}, your SwiftVTU wallet balance is running low.</p>

    <div class="amount-hero">
      <div class="amount-label">Current Balance</div>
      <div class="amount-value" style="color:#F59E0B">₦{balance:,.2f}</div>
    </div>

    <p>Fund your wallet now to continue enjoying seamless transactions.</p>

    <div style="text-align:center;margin:24px 0">
      <a href="{{frontend_url}}" class="btn">Fund Wallet Now</a>
    </div>
    """
    return subject, _wrap(subject, body, f"Your SwiftVTU balance is ₦{balance:,.2f} — top up now")


# ── 9. Account Blocked Alert ──────────────────────────────────────────────────
def account_blocked_email(first_name: str) -> tuple[str, str]:
    subject = "Your SwiftVTU account has been suspended"
    body = f"""
    <h1>Account Suspended</h1>
    <p>Hi {first_name}, your SwiftVTU account has been temporarily suspended.</p>

    <div class="alert-box">
      <p>⚠️ This may be due to suspicious activity or a violation of our Terms of Service.</p>
    </div>

    <p>If you believe this is a mistake, please contact our support team immediately and we'll resolve it as quickly as possible.</p>

    <div style="text-align:center;margin:24px 0">
      <a href="mailto:{{support_email}}" class="btn btn-red">Contact Support</a>
    </div>
    """
    return subject, _wrap(subject, body, "Your SwiftVTU account has been suspended — contact support")


# ── 10. Admin Wallet Credit/Debit ─────────────────────────────────────────────
def admin_wallet_action_email(
    first_name: str,
    action: str,       # credit | debit
    amount: float,
    note: str,
    new_balance: float,
) -> tuple[str, str]:
    is_credit = action == "credit"
    subject = f"{'💰 Wallet Credited' if is_credit else '💸 Wallet Debited'} — ₦{amount:,.2f} | SwiftVTU"
    body = f"""
    <h1>{'Wallet Credited' if is_credit else 'Wallet Debited'}</h1>
    <p>Hi {first_name}, your SwiftVTU wallet has been {'credited' if is_credit else 'debited'} by an administrator.</p>

    <div class="amount-hero">
      <div class="amount-label">{'Amount Added' if is_credit else 'Amount Removed'}</div>
      <div class="amount-value" style="color:{'#10B981' if is_credit else '#EF4444'}">
        {'+ ' if is_credit else '- '}₦{amount:,.2f}
      </div>
    </div>

    <div class="info-box">
      <div class="info-row">
        <span class="info-label">Action</span>
        <span class="info-value">Admin {'Credit' if is_credit else 'Debit'}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Reason</span>
        <span class="info-value">{note or 'Administrative adjustment'}</span>
      </div>
      <div class="info-row">
        <span class="info-label">New Balance</span>
        <span class="info-value" style="color:#10B981">₦{new_balance:,.2f}</span>
      </div>
    </div>

    <p style="font-size:13px;color:#94A3B8">Questions? Contact us at
    <a href="mailto:{{support_email}}" style="color:#3B82F6">{{support_email}}</a></p>
    """
    return subject, _wrap(subject, body, f"Your wallet has been {'credited' if is_credit else 'debited'} ₦{amount:,.2f}")

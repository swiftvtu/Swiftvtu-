"""
SwiftVTU Email Service
- Primary: SendGrid API
- Fallback: SMTP (Gmail, Zoho, custom)
- Async background sending (never blocks a request)
- Template variable substitution
- Retry logic
"""
import asyncio
import logging
import smtplib
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from typing import Optional

import httpx

from app.config import settings

logger = logging.getLogger(__name__)

SENDGRID_API = "https://api.sendgrid.com/v3/mail/send"

# ── Template variable substitution ───────────────────────────────────────────
def _fill_template(html: str, email_to: str) -> str:
    """Replace placeholder vars in all templates."""
    replacements = {
        "{frontend_url}":  settings.FRONTEND_URL,
        "{support_email}": settings.SUPPORT_EMAIL,
        "{email}":         email_to,
        "{requested_at}":  datetime.utcnow().strftime("%d %b %Y, %H:%M UTC"),
    }
    for key, val in replacements.items():
        html = html.replace(key, val)
    return html


# ── Core send function ────────────────────────────────────────────────────────
async def send_email(
    to_email: str,
    to_name: str,
    subject: str,
    html_body: str,
    text_body: str = "",
    retries: int = 2,
) -> bool:
    """
    Send a single email. Returns True on success.
    Tries SendGrid first, falls back to SMTP if configured.
    """
    html_body = _fill_template(html_body, to_email)

    # Auto-generate plain text from HTML if not provided
    if not text_body:
        text_body = re.sub(r"<[^>]+>", "", html_body).strip()
        text_body = re.sub(r"\n{3,}", "\n\n", text_body)

    for attempt in range(retries + 1):
        try:
            if settings.EMAIL_PROVIDER == "sendgrid" and settings.SENDGRID_API_KEY:
                success = await _send_via_sendgrid(to_email, to_name, subject, html_body, text_body)
            else:
                success = await _send_via_smtp(to_email, to_name, subject, html_body, text_body)

            if success:
                logger.info(f"✉️ Email sent to {to_email}: {subject}")
                return True

        except Exception as e:
            logger.warning(f"Email attempt {attempt + 1} failed for {to_email}: {e}")
            if attempt < retries:
                await asyncio.sleep(2 ** attempt)  # exponential back-off

    logger.error(f"❌ Failed to send email to {to_email} after {retries + 1} attempts")
    return False


# ── Fire-and-forget wrapper ───────────────────────────────────────────────────
def send_email_background(
    to_email: str,
    to_name: str,
    subject: str,
    html_body: str,
    text_body: str = "",
) -> None:
    """Schedule email sending as a background task — never blocks the request."""
    asyncio.create_task(
        send_email(to_email, to_name, subject, html_body, text_body)
    )


# ── SendGrid ──────────────────────────────────────────────────────────────────
async def _send_via_sendgrid(
    to_email: str, to_name: str, subject: str, html_body: str, text_body: str
) -> bool:
    payload = {
        "personalizations": [{
            "to": [{"email": to_email, "name": to_name}],
            "subject": subject,
        }],
        "from": {
            "email": settings.EMAIL_FROM,
            "name":  settings.EMAIL_FROM_NAME,
        },
        "reply_to": {
            "email": settings.SUPPORT_EMAIL,
            "name":  settings.EMAIL_FROM_NAME,
        },
        "content": [
            {"type": "text/plain", "value": text_body},
            {"type": "text/html",  "value": html_body},
        ],
        "tracking_settings": {
            "click_tracking":  {"enable": True},
            "open_tracking":   {"enable": True},
        },
    }

    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(
            SENDGRID_API,
            json=payload,
            headers={
                "Authorization": f"Bearer {settings.SENDGRID_API_KEY}",
                "Content-Type":  "application/json",
            },
        )
        if resp.status_code in (200, 202):
            return True
        logger.error(f"SendGrid error {resp.status_code}: {resp.text}")
        return False


# ── SMTP ──────────────────────────────────────────────────────────────────────
async def _send_via_smtp(
    to_email: str, to_name: str, subject: str, html_body: str, text_body: str
) -> bool:
    if not settings.SMTP_USER or not settings.SMTP_PASSWORD:
        logger.error("SMTP credentials not configured")
        return False

    def _smtp_send():
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = f"{settings.EMAIL_FROM_NAME} <{settings.EMAIL_FROM}>"
        msg["To"]      = f"{to_name} <{to_email}>"
        msg["Reply-To"] = settings.SUPPORT_EMAIL

        msg.attach(MIMEText(text_body, "plain", "utf-8"))
        msg.attach(MIMEText(html_body, "html",  "utf-8"))

        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as smtp:
            if settings.SMTP_USE_TLS:
                smtp.starttls()
            smtp.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            smtp.sendmail(settings.EMAIL_FROM, to_email, msg.as_string())
        return True

    # Run blocking SMTP in thread pool
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _smtp_send)


# ════════════════════════════════════════════════════════════════════════════
# HIGH-LEVEL EMAIL SENDERS
# Each function imports its template and fires the email in the background.
# ════════════════════════════════════════════════════════════════════════════

from app.services.email_templates import (
    welcome_email, verify_email, otp_email, password_reset_email,
    transaction_receipt, wallet_funded_email, transaction_failed_email,
    low_balance_email, account_blocked_email, admin_wallet_action_email,
)


def send_welcome(user_email: str, user_name: str, first_name: str, verification_url: str):
    subject, html = welcome_email(first_name, verification_url)
    send_email_background(user_email, user_name, subject, html)


def send_verification_otp(user_email: str, user_name: str, first_name: str, otp: str, verification_url: str):
    subject, html = verify_email(first_name, verification_url, otp)
    send_email_background(user_email, user_name, subject, html)


def send_otp(user_email: str, user_name: str, first_name: str, otp: str, action: str = "login"):
    subject, html = otp_email(first_name, otp, action)
    send_email_background(user_email, user_name, subject, html)


def send_password_reset(user_email: str, user_name: str, first_name: str, reset_url: str):
    subject, html = password_reset_email(first_name, reset_url)
    send_email_background(user_email, user_name, subject, html)


def send_transaction_receipt(
    user_email: str,
    user_name: str,
    first_name: str,
    tx_type: str,
    reference: str,
    amount: float,
    description: str,
    status: str,
    balance_after: float,
    date_str: str,
    token: Optional[str] = None,
    pins: Optional[list] = None,
    extra_rows: Optional[dict] = None,
):
    subject, html = transaction_receipt(
        first_name, tx_type, reference, amount, description,
        status, balance_after, date_str, token, pins, extra_rows
    )
    send_email_background(user_email, user_name, subject, html)


def send_wallet_funded(
    user_email: str, user_name: str, first_name: str,
    amount: float, gateway: str, reference: str, new_balance: float, date_str: str,
):
    subject, html = wallet_funded_email(first_name, amount, gateway, reference, new_balance, date_str)
    send_email_background(user_email, user_name, subject, html)


def send_transaction_failed(
    user_email: str, user_name: str, first_name: str,
    tx_type: str, reference: str, amount: float, reason: str = "",
):
    subject, html = transaction_failed_email(first_name, tx_type, reference, amount, reason)
    send_email_background(user_email, user_name, subject, html)


def send_low_balance_alert(user_email: str, user_name: str, first_name: str, balance: float):
    subject, html = low_balance_email(first_name, balance)
    send_email_background(user_email, user_name, subject, html)


def send_account_blocked(user_email: str, user_name: str, first_name: str):
    subject, html = account_blocked_email(first_name)
    send_email_background(user_email, user_name, subject, html)


def send_admin_wallet_action(
    user_email: str, user_name: str, first_name: str,
    action: str, amount: float, note: str, new_balance: float,
):
    subject, html = admin_wallet_action_email(first_name, action, amount, note, new_balance)
    send_email_background(user_email, user_name, subject, html)

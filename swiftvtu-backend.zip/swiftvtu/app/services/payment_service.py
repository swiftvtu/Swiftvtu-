"""
Paystack + Flutterwave wallet funding integrations.
"""
import httpx
import hmac
import hashlib
import logging
from app.config import settings

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════
# PAYSTACK
# ══════════════════════════════════════════════════════
PAYSTACK_BASE = "https://api.paystack.co"


def _paystack_headers() -> dict:
    return {
        "Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}",
        "Content-Type": "application/json",
    }


async def paystack_initialize(email: str, amount_kobo: int, reference: str, callback_url: str) -> dict:
    """
    Initialize a Paystack payment.
    Returns authorization_url to redirect user to.
    amount_kobo: amount in kobo (₦100 = 10000 kobo)
    """
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(
                f"{PAYSTACK_BASE}/transaction/initialize",
                json={
                    "email": email,
                    "amount": amount_kobo,           # Paystack expects kobo
                    "reference": reference,
                    "callback_url": callback_url,
                    "metadata": {"source": "swiftvtu_wallet_funding"},
                },
                headers=_paystack_headers(),
            )
            resp.raise_for_status()
            data = resp.json()
            if data.get("status"):
                return {
                    "success": True,
                    "authorization_url": data["data"]["authorization_url"],
                    "access_code": data["data"]["access_code"],
                    "reference": data["data"]["reference"],
                }
            return {"success": False, "message": data.get("message", "Paystack error")}
        except httpx.HTTPError as e:
            logger.error(f"Paystack init error: {e}")
            return {"success": False, "message": str(e)}


async def paystack_verify(reference: str) -> dict:
    """Verify a Paystack transaction by reference."""
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.get(
                f"{PAYSTACK_BASE}/transaction/verify/{reference}",
                headers=_paystack_headers(),
            )
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") and data["data"]["status"] == "success":
                return {
                    "success": True,
                    "amount_kobo": data["data"]["amount"],
                    "reference": data["data"]["reference"],
                    "gateway_reference": data["data"]["id"],
                    "channel": data["data"]["channel"],
                    "paid_at": data["data"]["paid_at"],
                }
            return {
                "success": False,
                "message": data["data"].get("gateway_response", "Payment not successful"),
            }
        except httpx.HTTPError as e:
            logger.error(f"Paystack verify error [{reference}]: {e}")
            return {"success": False, "message": str(e)}


def verify_paystack_webhook(payload: bytes, signature: str) -> bool:
    """Validate Paystack webhook signature."""
    expected = hmac.new(
        settings.PAYSTACK_WEBHOOK_SECRET.encode(),
        payload,
        hashlib.sha512,
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


# ══════════════════════════════════════════════════════
# FLUTTERWAVE
# ══════════════════════════════════════════════════════
FLW_BASE = "https://api.flutterwave.com/v3"


def _flw_headers() -> dict:
    return {
        "Authorization": f"Bearer {settings.FLW_SECRET_KEY}",
        "Content-Type": "application/json",
    }


async def flw_initialize(
    email: str, phone: str, name: str, amount_naira: float, reference: str, redirect_url: str
) -> dict:
    """
    Initialize a Flutterwave payment.
    Returns payment link to redirect user to.
    """
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(
                f"{FLW_BASE}/payments",
                json={
                    "tx_ref": reference,
                    "amount": amount_naira,             # FLW expects Naira
                    "currency": "NGN",
                    "redirect_url": redirect_url,
                    "customer": {"email": email, "phone_number": phone, "name": name},
                    "customizations": {
                        "title": "SwiftVTU Wallet Funding",
                        "description": "Fund your SwiftVTU wallet",
                    },
                    "meta": {"source": "swiftvtu_wallet_funding"},
                },
                headers=_flw_headers(),
            )
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") == "success":
                return {
                    "success": True,
                    "payment_link": data["data"]["link"],
                    "reference": reference,
                }
            return {"success": False, "message": data.get("message", "Flutterwave error")}
        except httpx.HTTPError as e:
            logger.error(f"Flutterwave init error: {e}")
            return {"success": False, "message": str(e)}


async def flw_verify(transaction_id: str) -> dict:
    """Verify a Flutterwave transaction by transaction ID."""
    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.get(
                f"{FLW_BASE}/transactions/{transaction_id}/verify",
                headers=_flw_headers(),
            )
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") == "success" and data["data"]["status"] == "successful":
                return {
                    "success": True,
                    "amount_naira": data["data"]["amount"],
                    "amount_kobo": int(data["data"]["amount"] * 100),
                    "reference": data["data"]["tx_ref"],
                    "gateway_reference": data["data"]["id"],
                    "channel": data["data"]["payment_type"],
                }
            return {
                "success": False,
                "message": data["data"].get("processor_response", "Payment not successful"),
            }
        except httpx.HTTPError as e:
            logger.error(f"Flutterwave verify error [{transaction_id}]: {e}")
            return {"success": False, "message": str(e)}


def verify_flw_webhook(payload: bytes, signature: str) -> bool:
    """Validate Flutterwave webhook signature."""
    expected = hmac.new(
        settings.FLW_WEBHOOK_SECRET.encode(),
        payload,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, signature)
